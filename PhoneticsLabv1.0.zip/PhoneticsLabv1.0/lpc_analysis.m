function lpc_coef=lpc_analysis(data,lpc_length,lpc_order,seg_length,method)
segments=ceil(length(data)/seg_length);
% zero padding, in order to align lpc coefficients at the center of the window
pre_zeros=floor((lpc_length-lpc_order)/2);
post_zeros=seg_length+lpc_length;
if ((method==2)|(method==3))
   data=filter([1;-.98],1,data);
   method=method-2;
end
data1=[zeros(pre_zeros,1);data(:);zeros(post_zeros,1)];
if method==0
   window_data=hamming(lpc_length);
end
for segs=1:segments
   lpc_range=((segs-1)*seg_length+1):((segs-1)*seg_length+lpc_length);
   if method==0
      % applying windows
      seg_data=data1(lpc_range).*window_data;
      % calculate lpc coefficients using lpc() function
      lpc_coef(segs,1:(lpc_order+1))=lpc(seg_data,lpc_order);
   else
      seg_data=data1(lpc_range);
      % calculate lpc coefficients using forword-backward covariance method
      data_h=hankel(seg_data(1:(lpc_length-lpc_order)),seg_data((lpc_length-lpc_order):end));
      data_h=[data_h(end:-1:1,end:-1:1);data_h];
      data_cov=data_h'*data_h;
      lpc_a=pinv(data_cov(1:end-1,1:end-1))*data_cov(1:end-1,end);
      lpc_coef(segs,1:(lpc_order+1))=[1,-lpc_a(end:-1:1)'];
   end
end

