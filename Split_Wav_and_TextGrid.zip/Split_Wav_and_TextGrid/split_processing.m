function split_processing(wav_file, textgrid_file, output_folder)
    % Read the WAV file (preserving the number of channels and sampling rate)
    [audio, fs] = audioread(wav_file);
    
    % Read the TextGrid file
    tiers = read_textgrid(textgrid_file);
    
    % Prompt the user to enter the tier name to split (default: "syllable")
    prompt = {'Enter the tier name to split (default: syllable):'};
    dlgtitle = 'Select TextGrid Reference Tier';
    dims = [1 50];
    definput = {'syllable'};
    answer = inputdlg(prompt, dlgtitle, dims, definput);
    
    % If the user cancels or leaves it empty, use the default
    if isempty(answer) || isempty(answer{1})
        tier_name = 'syllable';
    else
        tier_name = strtrim(answer{1}); % Remove unnecessary spaces
    end
    
    % Check if the tier exists in the TextGrid
    if ~isfield(tiers, tier_name)
        error('Tier "%s" not found in TextGrid.', tier_name);
    end
    
    % Get the selected tier
    selected_tier = tiers.(tier_name);
    
    % Initialize a dictionary to track duplicate file names
    existing_labels = containers.Map('KeyType', 'char', 'ValueType', 'double');
    
    % Iterate through each interval in the selected tier
    for i = 1:length(selected_tier)
        label = strtrim(selected_tier(i).text);
        start_time = selected_tier(i).xmin; % Start time
        end_time = selected_tier(i).xmax;   % End time
        
        % Skip if the interval has no label
        if isempty(label)
            continue;
        end
        
        % Handle duplicate names
        if isKey(existing_labels, label)
            existing_labels(label) = existing_labels(label) + 1;
            label = sprintf('%s_%d', label, existing_labels(label));
        else
            existing_labels(label) = 1;
        end
        
        % Extract the corresponding audio segment (preserving channels)
        start_sample = max(round(start_time * fs) + 1, 1);
        end_sample = min(round(end_time * fs), length(audio));
        segment_audio = audio(start_sample:end_sample, :); % Preserve stereo if applicable
        
        % Save the WAV file
        output_wav = fullfile(output_folder, [label, '.wav']);
        audiowrite(output_wav, segment_audio, fs);
        
        % Extract the corresponding TextGrid segment (preserving all tiers)
        output_textgrid = fullfile(output_folder, [label, '.TextGrid']);
        write_textgrid(output_textgrid, tiers, start_time, end_time);
    end
end
