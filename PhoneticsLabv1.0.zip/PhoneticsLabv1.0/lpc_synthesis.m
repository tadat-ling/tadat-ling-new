function syn_data=lpc_synthesis(residue,lpc_coef,seg_length)
lpc_order=length(lpc_coef(1,:))-1;
Zi_synthesize=zeros(lpc_order,1);
segments=ceil(length(residue)/seg_length);
% zero padding, in order to avoiding index overflow
residue1=[residue(:);zeros(seg_length+length(lpc_coef(1,:)),1)];
for segs=1:segments
   % calculate synthesize
   seg_range=((segs-1)*seg_length+1):(segs*seg_length);
   [syn_data(seg_range,1),Zi_synthesize]= ...
      filter(1,lpc_coef(segs,:),residue1(seg_range,1),Zi_synthesize);
end
% reformat residue to the size of original residue
syn_data=reshape(syn_data(1:prod(size(residue))),size(residue));
