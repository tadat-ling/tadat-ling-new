function residue=inverse_filter(data,lpc_coef,seg_length)
% initial status of inverse and synthesize filter.
lpc_order=length(lpc_coef(1,:))-1;
Zi_inverse=zeros(lpc_order,1);
segments=ceil(length(data)/seg_length);
% zero padding, in order to avoiding index overflow
data1=[data(:);zeros(seg_length+length(lpc_coef(1,:)),1)];
for segs=1:segments
   % calculate residues
   seg_range=((segs-1)*seg_length+1):(segs*seg_length);
   [residue(seg_range,1),Zi_inverse]= ...
      filter(lpc_coef(segs,:),1,data1(seg_range),Zi_inverse);
end
% reformat residue to the size of original data
residue=reshape(residue(1:prod(size(data))),size(data));
