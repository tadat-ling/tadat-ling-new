function[original_glottal_signal]=phoneticslab_klatt_invfilter(original_data,fmt_para,bw_para,fs)
%*********************************************************************************************
% input data and parameters
% 1) original_data:speech signal
% 2) fmt_para:formant parameters
% 3) bw_para:bandwidth
% 4) fs:sampling rate
% output data
% 1) original_glottal_signal:original glottal signal
%*********************************************************************************************
t=1/fs;%(reciprocal of sampling)
original_data_length=size(original_data);
fmt_number=length(fmt_para);

a_co=zeros(fmt_number,1);
b_co=zeros(fmt_number,1);
c_co=zeros(fmt_number,1);

a_inv_co=zeros(fmt_number,1);
b_inv_co=zeros(fmt_number,1);
c_inv_co=zeros(fmt_number,1);

for i=1:fmt_number
   b_co(i)=2*exp(-pi*bw_para(i)*t)*cos(2*pi*fmt_para(i)*t);
   c_co(i)=-exp(-2*pi*bw_para(i)*t);
   a_co(i)=1-b_co(i)-c_co(i);
   b_inv_co(i)=-b_co(i)/a_co(i);
   c_inv_co(i)=-c_co(i)/a_co(i);
   a_inv_co(i)=1.0/a_co(i);
end  

original_data_m=original_data;
   
for i=1:fmt_number
    for j=1:original_data_length-2
        original_data_s(j+2)=a_inv_co(i)*original_data_m(j+2)+b_inv_co(i)*original_data_m(j+1)+c_inv_co(i)*original_data_m(j);
    end
    original_data_m=original_data_s;
end
   
original_glottal_signal=original_data_m.';






