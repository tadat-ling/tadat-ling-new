%%%%%%%%%%%%%%%%%%%%%%%%%%
%output : F0 of speech
%input : 
%sp : speech
%nfft : number of FFT
%fs : frequency of sampling
%frameLength : Length of a Frame
%frameShift : Shift of Frames
%minf0 : minimal limit of F0
%maxf0 : maximal limit of F0
%%%%%%%%%%%%%%%%%%%%%%%%%%
function f0all=f0OfSpeech(sp,nfft,fs,minf0,maxf0,frameLength,frameShift)
    spFrame=enframe(sp,frameLength,frameShift);
    if size(spFrame,1)==0
        f0all=[];
        return;
    end
    f0all=zeros(1,size(spFrame,1));
     for i=1:size(spFrame,1)
        spw=(spFrame(i,:))'.*blackman(length((spFrame(i,:))'));
        fft_co=fft(spw,nfft);
        fft_spec=10*log(abs(fft_co));
        spec_log=fft_spec(1:nfft/2);
        cepstrum=dct(spec_log);
        leftedge=floor(fs/maxf0);
        rightedge=ceil(fs/minf0);
        if leftedge>length(cepstrum)
            f0all(i)=0;
            continue;
        end
        if rightedge>length(cepstrum)
            rightedge=length(cepstrum);
        end
        [~,f0p]=max(cepstrum(leftedge:rightedge));
        f0all(i)=fs/(f0p(1)+floor(fs/maxf0));
     end
end