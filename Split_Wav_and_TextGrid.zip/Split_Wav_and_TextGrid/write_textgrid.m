function write_textgrid(output_textgrid, tiers, start_time, end_time)
    fileID = fopen(output_textgrid, 'w');
    
    % Shift time to 0 to avoid time offset issues
    shift_time = start_time;
    
    fprintf(fileID, 'File type = "ooTextFile"\n');
    fprintf(fileID, 'Object class = "TextGrid"\n\n');
    fprintf(fileID, 'xmin = 0.0\n'); % Set the new TextGrid to start from 0
    fprintf(fileID, 'xmax = %.6f\n', end_time - start_time);
    fprintf(fileID, 'tiers? <exists>\n');
    fprintf(fileID, 'size = %d\n', length(fieldnames(tiers)));
    
    % Iterate through all tiers
    tier_names = fieldnames(tiers);
    for t = 1:length(tier_names)
        tier_name = tier_names{t};
        fprintf(fileID, 'item [%d]:\n', t);
        fprintf(fileID, '    class = "IntervalTier"\n');
        fprintf(fileID, '    name = "%s"\n', tier_name);
        fprintf(fileID, '    xmin = 0.0\n'); % Shift to 0
        fprintf(fileID, '    xmax = %.6f\n', end_time - start_time);
        
        % Filter intervals within the selected time range
        intervals = tiers.(tier_name);
        filtered_intervals = [];
        for i = 1:length(intervals)
            if intervals(i).xmax > start_time && intervals(i).xmin < end_time
                new_interval = struct();
                new_interval.xmin = max(intervals(i).xmin - shift_time, 0);
                new_interval.xmax = min(intervals(i).xmax - shift_time, end_time - start_time);
                new_interval.text = intervals(i).text;
                filtered_intervals = [filtered_intervals, new_interval];
            end
        end

        % **Ensure there is at least one interval to prevent empty tier issues**
        if isempty(filtered_intervals)
            filtered_intervals(1).xmin = 0.0;
            filtered_intervals(1).xmax = end_time - start_time;
            filtered_intervals(1).text = ""; % Avoid empty display issues
        end
        
        % Write the number of intervals
        fprintf(fileID, '    intervals: size = %d\n', length(filtered_intervals));
        
        % Write each interval
        for j = 1:length(filtered_intervals)
            fprintf(fileID, '    intervals [%d]:\n', j);
            fprintf(fileID, '        xmin = %.6f\n', filtered_intervals(j).xmin);
            fprintf(fileID, '        xmax = %.6f\n', filtered_intervals(j).xmax);
            fprintf(fileID, '        text = "%s"\n', filtered_intervals(j).text);
        end
    end
    
    fclose(fileID);
end
