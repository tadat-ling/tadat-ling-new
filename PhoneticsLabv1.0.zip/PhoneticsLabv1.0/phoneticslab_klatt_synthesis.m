function [synthesized_signal]=phoneticslab_klatt_synthesis(original_data,fmt_para,bw_para,fs)
%*********************************************************************************************
% input data and parameters
% 1) original_data
% 2) fmt_para,
% 3) bw_para
% 4) fs
% input data and parameters
% 1) synthesized signal
%*********************************************************************************************
t=1/fs;%(reciprocal of sampling)
[original_data_length hh]=size(original_data);
fmt_number=length(fmt_para);

a_co=zeros(fmt_number,1);
b_co=zeros(fmt_number,1);
c_co=zeros(fmt_number,1);

for i=1:fmt_number
   b_co(i)=2*exp(-pi*bw_para(i)*t)*cos(2*pi*fmt_para(i)*t);
   c_co(i)=-exp(-2*pi*bw_para(i)*t);
   a_co(i)=1-b_co(i)-c_co(i);
end  

synthesized_signal=original_data;
for i=1:fmt_number
    original_data_s=zeros(original_data_length,1);
    for j=1:original_data_length-2
        original_data_s(j+2)=a_co(i)*synthesized_signal(j+2)+b_co(i)*original_data_s(j+1)+c_co(i)*original_data_s(j);
    end
    synthesized_signal=original_data_s;
end
synthesized_signal=(synthesized_signal/(max(abs(synthesized_signal))))*0.8;



