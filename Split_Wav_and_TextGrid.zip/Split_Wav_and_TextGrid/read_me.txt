
Split Audio and TextGrid File

Author: Dat-Danny TA
Release Date: 2025.01.28

=============================

This program helps you split an audio file and its corresponding TextGrid file into separate smaller files based on a selected tier in the TextGrid. You are advised to run this program on MATLAB 2020b or later to ensure stable operation, and to install the Audio Toolbox and Signal Processing Toolbox.

For example, in your TextGrid file, the topmost tier (e.g., named "syllable") marks entire syllables, while the following tiers mark segments and selected parts for analysis. This program uses the "syllable" tier as a reference to split both the WAV and TextGrid files into smaller files, which are then saved using the label from Tier 1 of the extracted interval.


Instructions:

1. Open the script split_wav_annotate.m and click RUN.

2. Select the *.wav file.

3. Select the corresponding *.TextGrid file.

4. Choose the output folder.

5. Enter the tier name to use as the reference for splitting (default: "syllable").

6. Click OK and wait for the process to complete...

🎉 Congratulations! Your files have been successfully split! 🎉

