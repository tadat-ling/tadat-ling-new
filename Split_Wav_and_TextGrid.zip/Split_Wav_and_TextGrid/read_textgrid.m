function tiers = read_textgrid(filename)
    % Open TextGrid file
    fid = fopen(filename, 'r');
    if fid == -1
        error('Can not open TextGrid file.');
    end
    
    % Read the whole file as string
    file_content = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
    fclose(fid);
    file_content = file_content{1};
    
    % Find tiers
    tiers = struct();
    current_tier = '';
    for i = 1:length(file_content)
        line = strtrim(file_content{i});
        
        % Check the tiers' label
        if contains(line, 'name = ')
            current_tier = extractBetween(line, 'name = "', '"');
            current_tier = char(current_tier); % Make sure the current tier is a string
            tiers.(current_tier) = [];
        end
        
        % Check all of the intervals in the selected tier
        if contains(line, 'intervals [')
            interval_index = str2double(extractBetween(line, '[', ']'));
            xmin = str2double(extractAfter(file_content{i + 1}, 'xmin = '));
            xmax = str2double(extractAfter(file_content{i + 2}, 'xmax = '));
            text = extractBetween(file_content{i + 3}, 'text = "', '"');
            text = char(text); % Make sure the text is a string
            
            % Add information into the current tier
            tiers.(current_tier)(interval_index).xmin = xmin;
            tiers.(current_tier)(interval_index).xmax = xmax;
            tiers.(current_tier)(interval_index).text = text;
        end
    end
end
