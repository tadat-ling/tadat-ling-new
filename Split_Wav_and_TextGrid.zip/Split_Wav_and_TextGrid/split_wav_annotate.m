function split_wav_annotate()
    % Choose your WAV file
    [wav_file, wav_path] = uigetfile({'*.wav', 'Audio Files (*.wav)'}, 'Please choose your WAV file');
    if isequal(wav_file, 0)
        disp('Canceled.');
        return;
    end
    wav_file = fullfile(wav_path, wav_file);
    
    % Choose corresponding TextGrid
    [textgrid_file, textgrid_path] = uigetfile({'*.TextGrid', 'Praat TextGrid Files (*.TextGrid)'}, 'Please choose your TextGrid file');
    if isequal(textgrid_file, 0)
        disp('Canceled.');
        return;
    end
    textgrid_file = fullfile(textgrid_path, textgrid_file);
    
    % Choose output folder
    output_folder = uigetdir(pwd, 'Please choose output folder');
    if isequal(output_folder, 0)
        disp('Canceled.');
        return;
    end
    
    % Callback function
    split_processing(wav_file, textgrid_file, output_folder);
    disp('Congratulations! Your files have been successfully split!');
end
